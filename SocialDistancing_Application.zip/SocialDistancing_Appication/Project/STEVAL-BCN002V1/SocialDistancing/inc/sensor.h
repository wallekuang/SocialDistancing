/******************** (C) COPYRIGHT 2020 STMicroelectronics ********************
 * File Name          : sensor.c
 * Author             : SRA-SAIL
 * Version            : 1.0.0
 * Date               : 29-May-2020
 * Description        : Header file for Sensor Application
 ********************************************************************************
 * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
 * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
 * AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
 * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
 * CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
 * INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *******************************************************************************/

#ifndef _SENSOR_H_
#define _SENSOR_H_

#include <stdbool.h>
#include "LSM6DSO.h"	/* Accelerometer and Gyroscope*/
#include "LSM6DSO_hal.h"

#define X_OFFSET 200
#define Y_OFFSET 50
#define Z_OFFSET 1000

/** 
 * @brief Structure containing acceleration value of each axis.
 */
typedef struct {
  int32_t AXIS_X;
  int32_t AXIS_Y;
  int32_t AXIS_Z;
} AxesRaw_t;

typedef enum 
{
  IdleMode,
  NormalMode,
  LowProbabilityDetection,
  HighProbabilityDetection,
  SleepMode,
  NoMovementDetection
} LowPowerState;

typedef struct {
  bool HwFreeFall;
  bool HwPedometer;
  bool HwDoubleTAP;
  bool HwSingleTAP;
  bool HwWakeUp;
  bool HwTilt;
  bool HwOrientation6D;
  bool MultipleEvent;
} HardwareFeaturePresence;

void GetAccAxesRaw(void);
uint8_t Sensor_DeviceInit(void);
void APP_Tick(void);
void Init_Accelerometer(void);
void DisableHWFeatures(void);
void Interrupts_EXT_IO_Config(void);
void EnableHWWakeUp(void);
void RSSI_DangerZone(int8_t AvgFilter_RSSI, int16_t RelativeTiltX, int16_t RelativeTiltY, int16_t RelativeTiltZ);
void Fill_RSSI_In_Angle_Detection_Table(uint8_t aSampleCount, uint8_t nodeIndex, int8_t aReceive_RSSI, uint32_t Distance);
void Calculate_Device_TiltValue(void);
void Caliberate_Gain_And_Offset(void);
void Check_Acc_Status(void);
void MEMSCallback(void);
void MEMS_LatchIrqReset(void);
#endif /* _SENSOR_H_ */
