/******************** (C) COPYRIGHT 2020 STMicroelectronics ********************
 * File Name          : user_config.h
 * Author             : SRA-SAIL
 * Version            : 1.0.0
 * Date               : 29-May-2020
 * Description        : Header file for User configuration parameters
 ********************************************************************************
 * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
 * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
 * AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
 * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
 * CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
 * INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *******************************************************************************/

#ifndef _USER_CONFIG_H_
#define _USER_CONFIG_H_


#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

/* For generating an alert , if the any two or more than two devices comes in vicinity */   
#define RSSI_REDZONE         
/* Macro used to put the device in low power mode */   
#define LOW_POWER_FEATURE   
   
#ifndef DEBUG
#define DEBUG 0
#endif

#if DEBUG
#include <stdio.h>
#define PRINTF(...) printf(__VA_ARGS__)
#else
#define PRINTF(...)
#endif


/********************* Advertising and Scanning Interval **********************/
#ifdef LOW_POWER_FEATURE
#define ADV_INTERVAL_MIN                        240 /* 150ms */
#define ADV_INTERVAL_MAX                        240
#define SCAN_INTERVAL                           400 
#define SCAN_WINDOW                             360 
#define BEACON_CNT_HIGH_PROB_DETECTION          5

/***** High probability detection mode *******/
#define HIGH_PROBABILITY_ADV_INTERVAL_MIN       160 /* 100ms */
#define HIGH_PROBABILITY_ADV_INTERVAL_MAX       160 
#define HIGH_PROBABILITY_ADV_SCAN_INTERVAL      160 /*for high probability mode scan duty can be 100% and keeping adv , scan interval and window same*/
#define HIGH_PROBABILITY_ADV_SCAN_WINDOW        160 /* 100 ms */

#else /*LOW_POWER_FEATURE*/
#define ADV_INTERVAL_MIN                        190        
#define ADV_INTERVAL_MAX                        190
#define SCAN_INTERVAL                           100 /* 62.5 msec */   //160
#define SCAN_WINDOW                             100 /*62.5 msec */ //160

#endif /*LOW_POWER_FEATURE*/

/********************* Sleep Parameters **************************************/
#define MAX_BEACON_LOSS_COUNT                   4 /* no sleep upto 2 sec */


/* Device continuously checks if there is no beacon for (MAX_BEACON_LOSS_COUNT / 2) sec 
then device will switch in sleep mode for DEVICE_SLEEP_DURATION. */
#define DEVICE_SLEEP_DURATION                   1000 /* 1 second sleep*/ 


/* If no movement is detected from accelerometer for (DEVICE_HALT_TIME / 2) sec, 
it is assumed that user has removed the band and the device is put in the sleep mode. */
#define DEVICE_HALT_TIME                        120 /* 60 Sec */


/********************* Filter Parameters *************************************/

/* Set to 1 for enabling Flags AD Type position at the beginning of the 
   advertising packet */
#define N                                       4

/* alpha is related to time-constant. It is usually > 0.5
It controls how much you want the output to depend on the current value 
or a new value that arrives. */
#define ALPHA                                   0.6


/********************* Beacon Samples Parameters **********************/
#define MAX_NODE_COUNT                          20
#define MAX_SAMPLE                              20
#define MAX_ADVSCAN                             31

#define EN_HIGH_POWER_MODE                      1
#define PA_LEVEL                                4 /* 0x00 to 0x31 */
#define PI                                      3.14   

#define BLE_BEACON_VERSION_STRING "1.1.0"

#endif /* _USER_CONFIG_H_ */
