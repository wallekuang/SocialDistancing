
-------------------------------------------------------------------------------
-                    (C) COPYRIGHT 2020 STMicroelectronics                    -
- File:    Readme.txt                                                         -
- Author:  SRA-SAIL                                                           -
- Date:    1-June-2020                                                        -
- Version: V1.0.0                                                             -

-------------------------------------------------------------------------------
SocialDistancing/Readme.txt
---------------------------
This sample application shows how to use Social Distancing Detection Using Bluetooth� Low Energy.

Introduction :
===============
This social distancing application help users maintain safe distances and minimize the risk of contacting infectious diseases 
such as COVID-19 by generating an alert when two people come within a minimum set distance of each other, usually 2meters
or less. The application involves wireless Bluetooth� Low Energy (BLE) communication between wearable nodes based on the
BlueNRG-1 or BlueNRG-2 systems on chip.

The nodes simultaneously advertise their presence and scan for the presence of other similar beacons in range, while deploying
LowPower Modes during periods of inactivity to conserve battery power.

Advertising is performed on three channels and no connection or response packet are required between the devices during
advertising and scanning activities (ADV_NONCONN_IND).

RGB LED has been configured which will indicate whether the user is in safe zone or danger zone. If range is less than 2m, then red LED will toggle and indicate that the user is in danger zone.
If the range is more than 2m, then green LED will toggle indicating safe zone.


The binaries are provided in .bin format and can be flashed into the STEVAL-BCN002V1 board using one of the procedures described below. 

- Procedure 1 (.bin only) -
-------------------------

 1 - Plug the Eval Board to the host PC using a micro-USB cable. The board will be recognized as an external memory device called "BCN002V1".
 2 - Drag and drop or copy the binary file into the "BCN002V1" device you see in Computer.
 3 - Wait until flashing is complete.

- Procedure 2 (.hex and .bin) -
--------------------------------

 1 - Install BlueNRG-1 ST-Link Utility http://www.st.com/en/embedded-software/stsw-bnrg1stlink.html
 2 - Plug the Eval Board to the host PC using a micro USB cable.
 3 - Open the BlueNRG-1 ST-Link utility.
 4 - Connect to the board selecting "Target -> Connect" from the menu or pressing the corresponding button.
 5 - Open the binary file selecting "File -> Open File..." and choose the one you want to flash.
 6 - From the menu choose: "Target -> Program"
 7 - Click Start.
 8 - Wait until flashing is complete.

Workspace Used
---------------------------
1. EWARM 8.40.1
2. Keil 5.27.2 

Description of Binary files
---------------------------
SocialDistancing.bin: Binary file for Social Distancing application.

Different Binary files can be generated on the basis of their features like LOW_POWER_FEATURE ,RSSI_REDZONE,Traces by modifying user_config.h file.

Configuration setting :
----------------------
File name : user_config.h
File Path : Project\STEVAL-BCN002V1\SocialDistancing\inc
Description : Header file for User configuration parameters

User can enable\disable the following macros :
1) LOW_POWER_FEATURE : 
	a) Device continuously checks for Beacon. If there is no beacon for 2sec then device will switch in sleep mode for 1sec. 
	b) If no movement is detected from accelerometer for 60sec, it is assumed that user has removed the band and the device is put in the sleep mode until the device is tilted again.
	By default this feature is enabled

2) DEBUG        : Application debug messages will display on HyperTerminal if �DEBUG� macro is enabled.

3) RSSI_REDZONE : For generating an alert , if the any two or more than two devices comes in vicinity.  

4) All user configurable parameters are defined in user_config.h file . Any macro related changes and configuration parameters as mentioned below can be modifed using this file.
	� Advertising and Scanning Interval
	� Sleep duration
	� Filter Parameters
	� Beacon Samples Parameters (Max samples, Max node count)

5) RGB LED has been configured which will indicate whether the user is in safe zone or danger zone. If range is less than 2m, then red LED will toggle and indicate that the user is in danger zone.
If the range is more than 2m, then green LED will toggle indicating safe zone.

_______________________________________________________________________________
- (C) COPYRIGHT 2020 STMicroelectronics                   ****END OF FILE**** -
