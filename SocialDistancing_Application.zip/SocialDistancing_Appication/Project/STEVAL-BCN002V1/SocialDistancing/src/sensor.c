/******************** (C) COPYRIGHT 2020 STMicroelectronics ********************
 * File Name          : sensor.c
 * Author             : SRA-SAIL
 * Version            : 1.0.0
 * Date               : 29-May-2020
 * Description        : Sensor init and sensor state machines
 ********************************************************************************
 * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
 * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
 * AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
 * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
 * CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
 * INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *******************************************************************************/
/* Includes ------------------------------------------------------------------*/

#include "BlueNRG1_it.h"
#include "BlueNRG1_conf.h"
#include "ble_const.h" 
#include "bluenrg1_stack.h"
#include "gp_timer.h"
#include "SDK_EVAL_Config.h"
#include "sensor.h"
#include "user_config.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
   

#define UPDATE_CONN_PARAM 0 // Can be set to 1 only when no low power mode is used 


/* Private macro -------------------------------------------------------------*/
#ifdef RSSI_REDZONE 
/* Lookup Table : Relative Tilt vs RSSI */
 
/* const int table[][7] = {{Tiltx1, Tilty1, Tiltz1, Theta, RSSI Min, RSSI Max, RSSI Avg},
                    {Tiltx1, Tilty1, Tiltz1 , Theta + 90, RSSI Min, RSSI Max, RSSI Avg},
                    {Tiltx1, Tilty1, Tiltz1 , Theta + 180,  RSSI Min, RSSI Max, RSSI Avg},
                    {Tiltx1, Tilty1, Tiltz1 , Theta + 270,  RSSI Min, RSSI Max, RSSI Avg},

                    {Tiltx1 + 90, Tilty1, Tiltz1 + 90, Theta, RSSI Min, RSSI Max, RSSI Avg},
                    {Tiltx1 + 90, Tilty1, Tiltz1 + 90 , Theta + 90, RSSI Min, RSSI Max, RSSI Avg},
                    {Tiltx1 + 90, Tilty1, Tiltz1 + 90 , Theta + 180,  RSSI Min, RSSI Max, RSSI Avg},
                    {Tiltx1 + 90, Tilty1, Tiltz1 + 90 , Theta + 270,  RSSI Min, RSSI Max, RSSI Avg},

                    {Tiltx1, Tilty1 + 90, Tiltz1 + 90, Theta, RSSI Min, RSSI Max, RSSI Avg},
                    {Tiltx1, Tilty1 + 90, Tiltz1 + 90 , Theta + 90, RSSI Min, RSSI Max, RSSI Avg},
                    {Tiltx1, Tilty1 + 90, Tiltz1 + 90 , Theta + 180,  RSSI Min, RSSI Max, RSSI Avg},
                    {Tiltx1, Tilty1 + 90, Tiltz1 + 90 , Theta + 270,  RSSI Min, RSSI Max, RSSI Avg},

                    }; */   

/* Look up table � Relative tilt vs RSSI. Look up table values are filled on the basis of measurement scenario explained above. 
It can be further filled to observe deviation at different relative angle even if the distance is almost same. 
Objective of Look up table is to decide a band of RSSI sample for RED ZONE ie Distance < 2m. 
Conditional statement are derived with the help of  Look up table. */ 

/* Note: Look table value may change as per the environment, antenna direction and type of antenna
There can be more number of combination in X,Y,Z tilt or theta on same plane   */   
 
/* Theta (4th parameter in array) is deciced manually , by keeping one of device fixed and relatively changing 
the angle of other device on same plane ie 0, 90, 180, 270  for different tilt in X, Y, Z */  

const int table[][7] = {{0, 0, 0, 0, -67, -68, -67},  
                     {0, 0, 0, 90, -66, -68, -67},
                     {0, 0, 0, 180, -68, -70, -69},
                     {0, 0, 0, 270, -62, -63, -62},                    
                    {90, 0, 90, 0, -61, -63, -61},
                    {90, 0, 90, 90, -69, -73, -71},
                    {90, 0, 90, 180, -62, -66, -64},
                    {90, 0, 90, 270, -57, -60, -58},
                    {0, 90, 90, 0, -61, -65, -62},
                    {0, 90, 90, 90, -64, -67, -65},
                    {0, 90, 90, 180, -63, -69, -66},
                    {0, 90, 90, 270, -62, -65, -64},
                    };
#endif
/* Private variables ---------------------------------------------------------*/

#if UPDATE_CONN_PARAM
int l2cap_request_sent = FALSE;
struct timer l2cap_req_timer;
#endif


typedef struct
{
  float acc_x;        /* Acceleration in X axis in [g] */
  float acc_y;        /* Acceleration in Y axis in [g] */
  float acc_z;        /* Acceleration in Z axis in [g] */
} Acc_Gunit;
 

typedef struct 
{   
  float X_angle;
  float Y_angle;
  float Z_angle;
  int8_t rssi_factor;
} Acc_RSSI_Factor_t;

volatile uint8_t Request_WakeUP_Notify = FALSE; 
static axis3bit16_t ACC_RawData;
static float Acceleration_mg[3];
float X_Offset,Y_Offset,Z_Offset;
float X_Gain,Y_Gain,Z_Gain;

AxesRaw_t ACC_Data;
Acc_RSSI_Factor_t ACC_RSSI_Factor[MAX_NODE_COUNT] = {0};
lsm6dso_all_sources_t ALL_Source;
lsm6dso_pin_int1_route_t INT1_Route;
int16_t TiltAngleX = 0, TiltAngleY = 0,TiltAngleZ = 0; 
int16_t DeviceTilt[2][3] = {0,0,0,0,0,0};
extern uint8_t DeviceState;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/**
* @brief  Init_Accelerometer
* @brief  Initialize accelerometer sensor
* @param  None 
* @retval None
*/
void Init_Accelerometer(void)
{
  uint8_t rst;
  
  lsm6dso_i3c_disable_set(0, LSM6DSO_I3C_DISABLE);
  rst = lsm6dso_reset_set(0, PROPERTY_ENABLE);
  do {
    lsm6dso_reset_get(0, &rst);
  } while (rst);

 lsm6dso_pin_mode_set(0, LSM6DSO_PUSH_PULL);
 lsm6dso_pin_polarity_set(0, LSM6DSO_ACTIVE_LOW);
 lsm6dso_all_on_int1_set(0, PROPERTY_ENABLE);
 lsm6dso_int_notification_set(0, LSM6DSO_ALL_INT_LATCHED);

 lsm6dso_block_data_update_set(0, PROPERTY_ENABLE);
 lsm6dso_xl_power_mode_set(0, LSM6DSO_LOW_NORMAL_POWER_MD);
 lsm6dso_gy_power_mode_set(0, LSM6DSO_GY_NORMAL);
 lsm6dso_xl_data_rate_set(0, LSM6DSO_XL_ODR_52Hz);
 lsm6dso_gy_data_rate_set(0, LSM6DSO_GY_ODR_52Hz);
 lsm6dso_xl_full_scale_set(0, LSM6DSO_2g);
 lsm6dso_gy_full_scale_set(0, LSM6DSO_2000dps);
 
 lsm6dso_auto_increment_set(0, PROPERTY_ENABLE);  
 
 EnableHWWakeUp();
 
 /* Configure I/O interrupts */
 Interrupts_EXT_IO_Config();
 
}


/**
* @brief  DisableHWFeatures
* @brief  Disable h/w feature
* @param  None 
* @retval None
*/
void DisableHWFeatures(void) 
{
  lsm6dso_pin_int1_route_get(0, &INT1_Route);
  INT1_Route.reg.md1_cfg.int1_6d = PROPERTY_DISABLE;
  INT1_Route.reg.md1_cfg.int1_double_tap = PROPERTY_DISABLE;
  INT1_Route.reg.md1_cfg.int1_emb_func = PROPERTY_DISABLE;
  INT1_Route.reg.md1_cfg.int1_ff = PROPERTY_DISABLE;
  INT1_Route.reg.md1_cfg.int1_single_tap = PROPERTY_DISABLE;
  INT1_Route.reg.md1_cfg.int1_sleep_change = PROPERTY_DISABLE;
  INT1_Route.reg.md1_cfg.int1_wu = PROPERTY_DISABLE;
  lsm6dso_pin_int1_route_set(0, &INT1_Route);
 }


/**
* @brief  EnableHWWakeUp
* @brief  This function enables the HW's Wake Up Detection
* @param  None 
* @retval None
*/
void EnableHWWakeUp(void) 
{
  DisableHWFeatures();
  
  lsm6dso_xl_hp_path_internal_set(0, LSM6DSO_USE_SLOPE);
  lsm6dso_wkup_threshold_set(0, 2);
  lsm6dso_wkup_dur_set(0, 1);
  lsm6dso_pin_int1_route_get(0, &INT1_Route);
  INT1_Route.reg.md1_cfg.int1_wu = PROPERTY_ENABLE;
  lsm6dso_pin_int1_route_set(0, &INT1_Route);  
}

/**
* @brief  Interrupts_EXT_IO_Config
* @brief  Configure interrupts on GPIO pins
* @param  None 
* @retval None
*/
void Interrupts_EXT_IO_Config(void) 
{
  GPIO_InitType GPIO_InitStructure;
  GPIO_EXTIConfigType exti_config;
  NVIC_InitType NVIC_InitStructure;
  
  SysCtrl_PeripheralClockCmd(CLOCK_PERIPH_GPIO, ENABLE);
  
  NVIC_InitStructure.NVIC_IRQChannel = GPIO_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = MED_PRIORITY;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  /* Init Structure */
  GPIO_StructInit(&GPIO_InitStructure);
  
  /* Configure Wakeup IO pin */
  GPIO_InitStructure.GPIO_Mode = GPIO_Input;
  GPIO_InitStructure.GPIO_HighPwr = DISABLE;
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Pull = DISABLE;
  GPIO_Init(&GPIO_InitStructure);
  
  /* Configure the Interrupt */
  exti_config.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13;
  exti_config.GPIO_IrqSense = GPIO_IrqSense_Edge; /* GPIO_IrqSense_Level*/;
  exti_config.GPIO_Event = GPIO_Event_Low; /*GPIO_Event_Low;*/
  GPIO_EXTIConfig(&exti_config);
  
  GPIO_EXTICmd(GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13, ENABLE);
  
  /* Clear GPIO pending interrupt on SWD_CLK and SDK_EVAL_IRQ_SENSOR_PIN */
  GPIO_ClearITPendingBit(GPIO_Pin_13); 
}

/**
* @brief  GetAccAxesRaw
* @brief  Get raw value from accelerometer
* @param  None 
* @retval None
*/
void GetAccAxesRaw()
{
  memset(ACC_RawData.u8bit, 0x00, 3 * sizeof(int16_t));
  lsm6dso_acceleration_raw_get(0, ACC_RawData.u8bit);
  Acceleration_mg[0] = LSM6DSO_FROM_FS_2g_TO_mg(ACC_RawData.i16bit[0]);
  Acceleration_mg[1] = LSM6DSO_FROM_FS_2g_TO_mg(ACC_RawData.i16bit[1]);
  Acceleration_mg[2] = LSM6DSO_FROM_FS_2g_TO_mg(ACC_RawData.i16bit[2]);
  
  ACC_Data.AXIS_X = (int32_t) Acceleration_mg[0];
  ACC_Data.AXIS_Y = (int32_t) Acceleration_mg[1];
  ACC_Data.AXIS_Z = (int32_t) Acceleration_mg[2]; 
}

/**
* @brief  Fill_RSSI_In_Angle_Detection_Table
* @brief  Tilt angle corresponding to beacon received
* @param  aSampleCount :  Sample count
* @param  nodeIndex :  node index
* @param  aReceive_RSSI :  Receive RSSI value
* @param  Distance : Calculated distance
* @retval None
*/
void Fill_RSSI_In_Angle_Detection_Table(uint8_t aSampleCount, uint8_t nodeIndex, int8_t aReceive_RSSI, uint32_t Distance)
{
  ACC_RSSI_Factor[nodeIndex].X_angle        = TiltAngleX;
  ACC_RSSI_Factor[nodeIndex].Y_angle        = TiltAngleY;
  ACC_RSSI_Factor[nodeIndex].Z_angle        = TiltAngleZ;
  ACC_RSSI_Factor[nodeIndex].rssi_factor    = aReceive_RSSI;

  //PRINTF("%d : Acceleration_Data = %d   %d   %d   %d  %d\r\n", aSampleCount, TiltAngleX, TiltAngleY, TiltAngleZ, aReceive_RSSI, Distance);  
}

/**
* @brief  Calculate_Device_TiltValue
* @brief  Calculate Tilt value
* @param  None 
* @retval None
*/
void Calculate_Device_TiltValue()
{
  Acc_Gunit Acc_axis;
  
  GetAccAxesRaw();
  
  Acc_axis.acc_x = (((float) (Acceleration_mg[0])) / 1000);
  Acc_axis.acc_y = (((float) (Acceleration_mg[1])) / 1000);
  Acc_axis.acc_z = (((float) (Acceleration_mg[2])) / 1000);
  
  /********** A_Out = A_offset + K x A_Actual.************/ 
  /* Where
  * A_Actual  = Actual Acceleration value.
  * A_Out = Acceleration measured by Accelerometer 
  * A_offset = Offset value of acceleration along the Axis. 
  * K = Gain of Accelerometer
  */
  
  Acc_axis.acc_x =  X_Offset + X_Gain * Acc_axis.acc_x;
  Acc_axis.acc_y =  (Y_Offset + Y_Gain * Acc_axis.acc_y);
  Acc_axis.acc_z = (Z_Offset + Z_Gain * Acc_axis.acc_z); //A_Out = A_offset + K x A_Actual.
  
  TiltAngleX = (int16_t)(atan2(Acc_axis.acc_x,sqrt(pow(Acc_axis.acc_y,2)+pow(Acc_axis.acc_z,2)))*180/PI);
  TiltAngleY = (int16_t)(atan2(Acc_axis.acc_y,sqrt(pow(Acc_axis.acc_x,2)+pow(Acc_axis.acc_z,2)))*180/PI); 
  TiltAngleZ = (180 - (int16_t)(atan2(sqrt(pow(Acc_axis.acc_x,2)+pow(Acc_axis.acc_y,2)),Acc_axis.acc_z)*180/PI));
  
  //     /* Wake Up notification */
  if(Request_WakeUP_Notify == TRUE) 
  {
    Request_WakeUP_Notify = FALSE;  
  }
  //   printf(">>T : Acceleration Data = [%d] : [%d] : [%d]\r\n", TiltAngleX, TiltAngleY, TiltAngleZ); 
  //  printf("Acceleration Data = [%2.2f] : [%2.2f] : [%2.2f] \r\n", Acc_axis.acc_x, Acc_axis.acc_y, Acc_axis.acc_z); 
  
}


/**
* @brief  Caliberate_Gain_And_Offset
* @brief   Offset and Gain along each Axis can be calculated by taking two Reading 
 * of Accelerometer put at two different orientation 
 * (Can be taken as +g/-g orientation).
* @param  None 
* @retval None
*/
void Caliberate_Gain_And_Offset()
{
  /****** Accelerometer reading (X,Y,Z) at +g and -g orientation *********/
  float AccX_G1 = 1.01;
  float AccX_G2 = -1.01;
  float AccZ_G1 = 1.03;
  float AccZ_G2 = -1.01;
  float AccY_G1 = 1.00;
  float AccY_G2 = -0.99;
  
  /*********** calculate Offset along each Axis ***********/
  X_Offset = (float)(AccX_G1 + AccX_G2) / 2;
  Y_Offset = (float)(AccY_G1 + AccY_G2) / 2;
  Z_Offset = (float)(AccZ_G1 + AccZ_G2) / 2;
  
  /********** calculate Gain along each Axis ************/
  X_Gain = (float)(AccX_G2 - AccX_G1) / 2;
  Y_Gain = (float)(AccY_G2 - AccY_G1) / 2;
  Z_Gain = (float)(AccZ_G2 - AccZ_G1) / 2;
  
}

#ifdef RSSI_REDZONE 
/**
* @brief  RSSI_DangerZone
* @brief  Relative tilt value received in beacon data from nearby device
* @param  AvgFilter_RSSI : RSSI obtained after weighted mean and Average filter
* @param  RelativeTiltX :  Tilt Angle in X axis of nearby device received in beacon 
* @param  RelativeTiltY :  Tilt Angle in Y axis of nearby device received in beacon
* @param  RelativeTiltZ :  Tilt Angle in Z axis of nearby device received in beacon
* @retval None
*/
void RSSI_DangerZone(int8_t AvgFilter_RSSI, int16_t RelativeTiltX, int16_t RelativeTiltY, int16_t RelativeTiltZ)
{
  int16_t RelativeDifferenceX = abs(abs(TiltAngleX) - abs(RelativeTiltX));
  int16_t RelativeDifferenceY = abs(abs(TiltAngleY) - abs(RelativeTiltY));
  int16_t RelativeDifferenceZ = abs(abs(TiltAngleZ) - abs(RelativeTiltZ));
  
  if(AvgFilter_RSSI > -67)
  {
    PRINTF("DangerZone");
    RedLedToggle();
  }
  else if (AvgFilter_RSSI <= -67)
  {
    if ((RelativeDifferenceX < 20) && (RelativeDifferenceY < 20) && (RelativeDifferenceZ < 20))
    {
      if (AvgFilter_RSSI >= -70)
      {
        PRINTF("DangerZone");
        RedLedToggle();
      }
      else
      {
        PRINTF("No DangerZone");
        GreenLedToggle();
      }
    }
    else if ((RelativeDifferenceX > 20 && RelativeDifferenceX < 90) && (RelativeDifferenceY < 20)  && (RelativeDifferenceZ > 20 && RelativeDifferenceZ < 90))
    {
      if (AvgFilter_RSSI >= -72)
      {
        PRINTF("DangerZone");
        RedLedToggle();
      }
      else
      {
        PRINTF("No DangerZone");
        GreenLedToggle();
      }
     }
    else if ((RelativeDifferenceX < 20) && (RelativeDifferenceY > 20 && RelativeDifferenceY < 90) && (RelativeDifferenceZ > 20 && RelativeDifferenceZ < 90))
    {
      if (AvgFilter_RSSI >= -69)
      {
        PRINTF("Danger Zone");
        RedLedToggle();
      }
      else 
      {
        PRINTF("Safe Zone");
        GreenLedToggle();
      }
     }
    else 
      {
        PRINTF("No DangerZone");
        GreenLedToggle();
      }
  }
}
#endif

/**
* @brief  Check_Acc_Status
* @brief  Check Accelerometer status for sleep mode decision
* @param  None
* @retval None
*/
void Check_Acc_Status()
{
  static uint8_t offset = 0;
  static uint8_t device_movement_cnt;

  if(offset == 0 ) /* first entry */
  {
    DeviceTilt[0][0] = TiltAngleX;
    DeviceTilt[0][1] = TiltAngleY;
    DeviceTilt[0][2] = TiltAngleZ;
    offset ++;
  }
  else
  {
    DeviceTilt[1][0] = TiltAngleX;
    DeviceTilt[1][1] = TiltAngleY;
    DeviceTilt[1][2] = TiltAngleZ;  
    offset = 0;    
  }
  
  if((abs(DeviceTilt[0][0] - DeviceTilt[1][0]) <= 3)
     &&(abs(DeviceTilt[0][1] - DeviceTilt[1][1] <= 3))
       &&(abs(DeviceTilt[0][2] - DeviceTilt[1][2]) <= 3))
  {
    device_movement_cnt ++;
    //   PRINTF("device_movement_cnt %d \r\n", device_movement_cnt);
  }
  else
  {
    device_movement_cnt = 0;
  }
  
  if(device_movement_cnt == DEVICE_HALT_TIME) 
  {
    device_movement_cnt = 0;  
    DeviceState = NoMovementDetection;
    PRINTF("DEVICE_HALT_TIME_SLEEPMODE \r\n");
  }
  
}
/**
* @brief  MEMS_LatchIrqReset
* @brief  Check the interrupt source of MEMS
* @param  None
* @retval None
*/
void MEMS_LatchIrqReset(void)
{
  lsm6dso_all_sources_get(0, &ALL_Source);
}

/*******************************************************************************
 * Function Name  : MEMSCallback
 * Description    : Send Notification where there is a interrupt from MEMS
 * Input          : None
 * Return         : None
 *******************************************************************************/
void MEMSCallback(void) 
{
  /* Check if the interrupt is due to Wake Up */
  if (ALL_Source.reg.all_int_src.wu_ia) 
  {
    //	SdkEvalLedOn(LED1);
    //	SdkEvalLedOn(LED2);
    //	SdkEvalLedOn(LED3);
//    GreenLedOn();
    Request_WakeUP_Notify = TRUE;
    PRINTF("Event: Hardware Wakeup\n\r");   
    DeviceState = NormalMode;
  }    
  
  if (ALL_Source.reg.emb_func_status.is_tilt) 
  {
    //	SdkEvalLedOn(LED2);
    PRINTF("Event: Tilt\n\r");	
  }

}
