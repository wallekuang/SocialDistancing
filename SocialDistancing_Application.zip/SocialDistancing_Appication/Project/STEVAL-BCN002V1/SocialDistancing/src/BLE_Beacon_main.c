
/******************** (C) COPYRIGHT 2020 STMicroelectronics ********************
* File Name          : BLE_Beacon_main.c
* Author             : SRA-SAIL
* Version            : 1.0.0
* Date               : 29-May-2020
* Description        : Code demostrating the BLE Beacon application
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

   
/** @addtogroup Social Distancing application
 *  BlueNRG-1 Beacon demo \see BLE_Beacon_main.c for documentation.
 *
 *@{
 */

/** @} */
/** \cond DOXYGEN_SHOULD_SKIP_THIS
 */

/* Includes ------------------------------------------------------------------*/

#include "BlueNRG1_it.h"
#include "BlueNRG1_conf.h"
#include "ble_const.h"
#include "bluenrg1_events.h"
#include "bluenrg1_stack.h"
#include "sleep.h"
#include "SDK_EVAL_Config.h"
#include "Beacon_config.h"
#include "osal.h"
#include "clock.h"
#include "sensor.h"
#include "user_config.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
#ifdef LOW_POWER_FEATURE
BOOL BEACON_Received = FALSE;
uint8_t BEACON_LossCount = 0;
uint16_t BEACON_Count = 0;
uint8_t DeviceState = IdleMode;
uint32_t SysRefCount; 
static uint32_t DelayCounter = 0;
#endif /* LOW_POWER_FEATURE */
uint8_t bdaddress[6];

typedef struct
{
    Advertising_Report_t Advertising_Report;
    uint8_t data[MAX_ADVSCAN];
} adv_report;
adv_report pBeaconData;

/* Data structure for storing multiple beacons info */
typedef struct {
    uint8_t BDADDR_ID[6];
    int8_t rssi_value[MAX_SAMPLE];
    uint8_t txpower_value[MAX_SAMPLE];
    tClockTime timestamp[MAX_SAMPLE];
    uint8_t end_index;
    uint8_t valid;
}Beacon_Data;
Beacon_Data sBeacon[MAX_NODE_COUNT] = {0};

uint8_t Calculate_NodeIndex(uint8_t* bdaddr);
uint8_t MeasuredPower;
uint32_t Filtered_Distance,MeanWeighted_Distance;
int8_t Filter_RSSI,Current_RSSI,Previous_RSSI,AverageFilter_RSSI;
uint8_t ReadAccValue = 0;
uint8_t entry_point = 0;
extern uint8_t AXEL_EventDetected;
extern int16_t TiltAngleX, TiltAngleY,TiltAngleZ; 


/* Private function prototypes -----------------------------------------------*/
void Appli_Process(void);
void GPIO_Configuration(void); 

#ifdef LOW_POWER_FEATURE
void Sleep_State(void);
void Sleep_NoMovementDetection(void);
void printWakeupSource(void);
#endif /* LOW_POWER_FEATURE */
tBleStatus Update_Adv_Interval( uint16_t aAdvInterval_Min,uint16_t aAdvInterval_Max);
void GetMACfromUniqueNumber(void);
/* Private functions ---------------------------------------------------------*/
void GetMACfromUniqueNumber(void)
{
#define BNRG1_UNIQUE_NUMBER_ADDR (0x100007F4)

  /*
  The unique serial number is a six bytes value stored at address 0x100007F4: 
  it is stored as two words (8 bytes) at address 0x100007F4 and 0x100007F8 
  with unique serial number padded with 0xAA55.
  */
  uint8_t *pdst;
  uint8_t *psrc;
  uint8_t i;
  
  
  pdst = (uint8_t*) (bdaddress);
  psrc = (uint8_t*)(BNRG1_UNIQUE_NUMBER_ADDR);
  
  for (i=0; i<6; i++)
  { /* Read only 6 Bytes for MAC Address */
    *pdst = *psrc;
    pdst++;
    psrc++;
  }
  for(uint8_t j=0;j<6;j++)
    {
      PRINTF(" [%02x] \t", bdaddress[j]);
    }
  PRINTF("\r\n");
}
/**
* @brief  initialize BLE device
* @param  None 
* @retval None
*/
void Device_Init(void)
{
  uint8_t ret;
  uint16_t service_handle;
  uint16_t dev_name_char_handle;
  uint16_t appearance_char_handle;
  
  /* Set the TX Power to -2 dBm */
  ret = aci_hal_set_tx_power_level(EN_HIGH_POWER_MODE,PA_LEVEL);
  if(ret != 0) 
  {
    PRINTF ("Error in aci_hal_set_tx_power_level() 0x%04xr\n", ret);
    while(1);
  }
  GetMACfromUniqueNumber();
  ret = aci_hal_write_config_data(CONFIG_DATA_PUBADDR_OFFSET, CONFIG_DATA_PUBADDR_LEN, bdaddress);
  if(ret != 0) {
   PRINTF ("Error in aci_hal_write_config_data() 0x%04xr\n", ret);
    while(1);
  }
  else
    PRINTF ("aci_hal_write_config_data() --> SUCCESS\r\n");
  
  /* Init the GATT */
  ret = aci_gatt_init();
  if (ret != 0) 
    PRINTF ("Error in aci_gatt_init() 0x%04xr\n", ret);
  else
    PRINTF ("aci_gatt_init() --> SUCCESS\r\n");
  
  /* Init the GAP */
  ret = aci_gap_init((GAP_PERIPHERAL_ROLE | GAP_OBSERVER_ROLE), 0x00, 0x00, &service_handle, 
                     &dev_name_char_handle, &appearance_char_handle);
  if (ret != 0)
    PRINTF ("Error in aci_gap_init() 0x%04x\r\n", ret);
  else
    PRINTF ("aci_gap_init() --> SUCCESS\r\n");
}


/**
* @brief  Start beaconing
* @param  None 
* @retval None
*/
static void Start_Beaconing(void)
{  
  tBleStatus ret = BLE_STATUS_SUCCESS;
  
  /* Set AD Type Flags at beginning on Advertising packet  */
  uint8_t adv_data[] = {
    /* Advertising data: Flags AD Type */
    0x02, 
    0x01, 
    0x06, 
    /* Advertising data: manufacturer specific data */
    26, /* len */
    AD_TYPE_MANUFACTURER_SPECIFIC_DATA,  /* manufacturer type */
    0x30, 0x00, /* Company identifier code (Default is 0x0030 - STMicroelectronics: To be customized for specific identifier) */
    0x02,       /* ID  */
    0x15,       /* Length of the remaining payload */
    0xE2, 0x0A, 0x39, 0xF4, 0x73, 0xF5, 0x4B, 0xC4, /* Location UUID */
    0xA1, 0x2F, 0x17, 0xD1, 0xAD, 0x07, 0xA9, 0x61,
    0x00, 0x00, /* Major number */
    0x00, 0x00, /* Minor number */
    0xC8        /* 2's complement of the Tx power (-56dB)};  */     
  };
  
  /* disable scan response */
  ret = hci_le_set_scan_response_data(0,NULL);
  if (ret != BLE_STATUS_SUCCESS)
  {
    PRINTF ("Error in hci_le_set_scan_resp_data() 0x%04x\r\n", ret);
    return;
  }
  else
    PRINTF ("hci_le_set_scan_resp_data() --> SUCCESS\r\n");
  
  /* put device in non connectable mode */
  ret = aci_gap_set_discoverable(ADV_NONCONN_IND, ADV_INTERVAL_MIN, ADV_INTERVAL_MAX, PUBLIC_ADDR, NO_WHITE_LIST_USE,
                                 0, NULL, 0, NULL, 0, 0); 
  if (ret != BLE_STATUS_SUCCESS)
  {
    PRINTF ("Error in aci_gap_set_discoverable() 0x%04x\r\n", ret);
    return;
  }
  else
    PRINTF ("aci_gap_set_discoverable() --> SUCCESS\r\n");
  
  ret = aci_gap_start_observation_proc(SCAN_INTERVAL,SCAN_WINDOW,NO_WHITE_LIST_USE, PUBLIC_ADDR, 0x00, 0x00);
  
  if (ret != BLE_STATUS_SUCCESS)
  {
    PRINTF ("Error in aci_gap_start_observation_procedure() 0x%04x\r\n", ret);
    return;
  }
  else
    PRINTF ("aci_gap_start_observation_procedure() --> SUCCESS\r\n");
  
  /* Set the  ADV data with the Flags AD Type at beginning of the 
  advertsing packet,  followed by the beacon manufacturer specific data */
  ret = hci_le_set_advertising_data (sizeof(adv_data), adv_data);
  if (ret != BLE_STATUS_SUCCESS)
  {
    PRINTF ("Error in hci_le_set_advertising_data() 0x%04x\r\n", ret);
    return;
  }
  else
    PRINTF ("hci_le_set_advertising_data() --> SUCCESS\r\n");
  
}

/************** Weighted Mean/Feedback Filtering ******************************/
/**
* @brief  Weighted Mean
* @param  aPrevious_RSSI: Previous RSSI value of Beacon of same node 
* @param  aCurrent_RSSI: Current RSSI value of Beacon of same node 
* @retval int8_t: Return Filter RSSI
*/

int8_t Weighted_Mean(int8_t aPrevious_RSSI,int8_t aCurrent_RSSI)
{
  int8_t filter_rssi = 0;
  filter_rssi = (int8_t)(((1 - ALPHA) * aCurrent_RSSI) + (ALPHA * aPrevious_RSSI));  
  return filter_rssi;
}

/****************** Average Filter ************************************/
/**
* @brief  Average_Filter 
* @param  aNodeIndex: Node Index
* @param  aSample_count: Sample received for specific beacon node
* @retval int16_t: Return Average RSSI
*/
int16_t Average_Filter(uint8_t aNodeIndex,uint8_t aSample_count)
{
  int16_t Total_RSSI=0;
  for(uint8_t count=0;count <= aSample_count ; count++)
  {
    Total_RSSI = Total_RSSI + sBeacon[aNodeIndex].rssi_value[count] ;
  }
  return (Total_RSSI / (aSample_count + 1)) ;
}

/**
 * @brief The LE Advertising Report event indicates that a Bluetooth device or
 *        multiple Bluetooth devices have responded to an active scan or
 *        received some information during a passive scan. The Controller may
 *        queue these advertising reports and send information from multiple
 *        devices in one LE Advertising Report event.
 * @param Num_Reports Number of responses in this event.
 *        Values:
 *        - 0x01
 * @param Advertising_Report See @ref Advertising_Report_t
 * @retval None
 */
void hci_le_advertising_report_event(uint8_t Num_Reports, Advertising_Report_t Advertising_Report[])
{ 
  /* Parse advertising reports */
  for (int i = 0; i < Num_Reports; i++)
  {  
    if ( Advertising_Report[i].Length_Data == 0x1e  && Advertising_Report[i].Data[0] == 0x02 && Advertising_Report[0].Event_Type == 0x03)
    {
      
      uint8_t bd_addr[6] = {0x00,0x00,0x00,0x00,0x00,0x00};
      uint8_t nodeIndex =0;
      
      memcpy(bd_addr,Advertising_Report[i].Address,6);
      
      nodeIndex = Calculate_NodeIndex(bd_addr);
      if (nodeIndex == 0xFF)
      {
        /* No memory available for new node */
        return ;
      }
      else
      {
        
        uint8_t sample_count = 0;          
        memcpy(sBeacon[nodeIndex].BDADDR_ID,Advertising_Report[i].Address,6);
        sample_count = sBeacon[nodeIndex].end_index;
        /**********Tilt angle of beacon received*******************************/ 
       int16_t RelativeTiltX  = Advertising_Report[i].Data[Advertising_Report[i].Length_Data - 21]; 
       int16_t RelativeTiltY  = Advertising_Report[i].Data[Advertising_Report[i].Length_Data - 20]; 
       int16_t RelativeTiltZ  = Advertising_Report[i].Data[Advertising_Report[i].Length_Data - 19];
        
        /******* Calculate Current RSSI ******************/
        Current_RSSI = Advertising_Report[i].RSSI;
        // PRINTF ("Current RSSI %d \t", Current_RSSI);
        
        /******* Fill Txpower and timestamp in  sBeacon structure **********/
        sBeacon[nodeIndex].txpower_value[sample_count] = Advertising_Report[i].Data[Advertising_Report[i].Length_Data - 1];
        MeasuredPower = sBeacon[nodeIndex].txpower_value[sample_count];  
        sBeacon[nodeIndex].timestamp[sample_count]  =  Clock_Time();
        
        /*************** Filter RSSI ******************/
        if (sBeacon[nodeIndex].end_index > 0)
        {
          Previous_RSSI = sBeacon[nodeIndex].rssi_value[sample_count - 1];  
          
          /*********** Apply Complementary Filter *************************/
          Filter_RSSI = Weighted_Mean(Previous_RSSI,Current_RSSI);        
          sBeacon[nodeIndex].rssi_value[sample_count] = Filter_RSSI;    
          
          /*********** Apply Average Filter *******************************/
          AverageFilter_RSSI = Average_Filter(nodeIndex,sample_count);
#ifdef RSSI_REDZONE        
          RSSI_DangerZone(AverageFilter_RSSI, RelativeTiltX, RelativeTiltY, RelativeTiltZ);
#endif          
          Filtered_Distance = (uint32_t)(1000 * pow(10, ((float)((int8_t)MeasuredPower - (int8_t)AverageFilter_RSSI)/(10 * N))));
        }
        else
        {
          Filter_RSSI = Current_RSSI;      
          sBeacon[nodeIndex].rssi_value[sample_count] = Filter_RSSI;        
        }
        
#ifdef LOW_POWER_FEATURE
        /* For power management */
        BEACON_Received = TRUE;
        BEACON_LossCount = 0;
        BEACON_Count++;
        PRINTF("BEACON_Count %d \r\n", BEACON_Count);
#endif /* LOW_POWER_FEATURE */

        Fill_RSSI_In_Angle_Detection_Table(sample_count, nodeIndex, AverageFilter_RSSI, Filtered_Distance);
        sBeacon[nodeIndex].end_index=(sample_count + 1)% MAX_SAMPLE;    
        
        /******************* Calculate Distance in cm  ******************/
        /****** Distance = 10 ^ ((Tx Power � RSSI)/(10 * N)) ******/  
            
        PRINTF(" \r\n");
      }        
    }
    else
    {
      //    PRINTF("discard packet due to unsupported format\r\n");
    }
  }
  
}

int main(void) 
{
  uint8_t ret;
  
  /* System Init */
  SystemInit();

  /* Identify BlueNRG-2 platform */
  SdkEvalIdentification();
  
  /* Configure I/O communication channel */
  SdkEvalComUartInit(UART_BAUDRATE);

  Clock_Init();
  SysCtrl_PeripheralClockCmd(CLOCK_PERIPH_PKA, ENABLE);

  /* BlueNRG-1 stack init */
  ret = BlueNRG_Stack_Initialization(&BlueNRG_Stack_Init_params);
  if (ret != BLE_STATUS_SUCCESS) 
  {
    PRINTF("Error in BlueNRG_Stack_Initialization() 0x%02x\r\n", ret);
    while(1);
  }
  else
    PRINTF("Success in BlueNRG_Stack_Initialization() 0x%02x\r\n", ret);
    
  SdkEvalLedInit(LED3);
  SdkEvalLedInit(LED2);
  SdkEvalLedInit(LED1);
  
  /* Init the BlueNRG-1 device */
  Device_Init();
 
  /* Configure I2C @ 400 kHz */
  SdkEvalI2CInit(400000);
        
  Init_Accelerometer();
  
  /* Start Beacon Non Connectable Mode*/
  Start_Beaconing();
  
  Caliberate_Gain_And_Offset();
  PRINTF("BlueNRG-1 BLE Beacon Application (version: %s)\r\n", BLE_BEACON_VERSION_STRING); 
  SdkEvalLedOff(LED3); 
  SdkEvalLedOff(LED1); /* RED LED */
  SdkEvalLedOff(LED2);
  while(1) 
  {
    BTLE_StackTick();   
    Appli_Process();    
  }
}

/**
* @brief  Application Process
* @param  None
* @retval void
*/
void Appli_Process()
{
  if(ReadAccValue)
  {
    Calculate_Device_TiltValue();
    ReadAccValue = 0;
    
#ifdef LOW_POWER_FEATURE    
    if(BEACON_Received == FALSE)
      BEACON_LossCount ++;    
    
    Check_Acc_Status();
    
    if((BEACON_Count > BEACON_CNT_HIGH_PROB_DETECTION) && (DeviceState != NoMovementDetection))
      DeviceState =  HighProbabilityDetection;
    else 
      BEACON_Count = 0;
#endif  //LOW_POWER_FEATURE   
  }
  
  
#ifdef LOW_POWER_FEATURE   
  BEACON_Received = FALSE;   
  /* if no Beacon received from last 2 sec then activate sleep mode */
  if(BEACON_LossCount == MAX_BEACON_LOSS_COUNT)
  {
    BEACON_LossCount = 0;
    
    if(DeviceState != NoMovementDetection)
        DeviceState =  SleepMode;
  }
  Sleep_State();
  
  if (AXEL_EventDetected == 1)
  {
    AXEL_EventDetected = 0;
    MEMSCallback();
    
    /* Delay to avoid multi event generation. */
    do {
      DelayCounter++;
      MEMS_LatchIrqReset();
    }
    while(DelayCounter<250);
    DelayCounter = 0;
    GPIO_ClearITPendingBit(GPIO_Pin_13);
    GPIO_EXTICmd(GPIO_Pin_13, ENABLE);
  }
  
#endif   /*LOW_POWER_FEATURE */
#ifndef LOW_POWER_FEATURE
  Update_Adv_Interval(ADV_INTERVAL_MIN,ADV_INTERVAL_MAX);
#endif
}

/**
* @brief  Application Low Power Process : Application in sleep mode when no beacon is received 
* @param  None
* @retval void
*/
void Appli_LowPowerProcess(void)
{
#ifdef LOW_POWER_FEATURE  
  PRINTF("\r\n******State = %d \r\n",DeviceState);
  uint8_t ret;
  /* Timer 0 used for low power */
  ret = HAL_VTimerStart_ms(0, DEVICE_SLEEP_DURATION);
  if (ret != SUCCESS) 
  {
    PRINTF("HAL_VTimerStart_ms() error 0x%02x\r\n", ret);
    while(1);
  }  
  /* To start virtual timer */
  BTLE_StackTick();
  
  /* save virtual timer current count */
  SysRefCount = HAL_VTimerGetCurrentTime_sysT32();
  
  /* Check UART Busy status */
  //while(SdkEvalComUARTBusy() == SET);
  
  /* wakeup either from io or virtual timer */
  ret = BlueNRG_Sleep(SLEEPMODE_WAKETIMER, 0, 0); //wakeup from virtual timer
  if (ret != SUCCESS) 
  {
    PRINTF("BlueNRG_Sleep() error 0x%02x\r\n", ret);
    while(1);
  }  
  printWakeupSource();
  
  /* update systick count based on updated virtual timer count */
  Set_Clock_Time(Clock_Time() + 
                 HAL_VTimerDiff_ms_sysT32(HAL_VTimerGetCurrentTime_sysT32(),
                                          SysRefCount));
  
  /* Stop Timer 0 */
  HAL_VTimer_Stop(0);
#endif /*LOW_POWER_FEATURE  */
}

/**
* @brief  Calculate Node Index
* @param  bdaddr: Address of specific beacon
* @retval uint8_t : return count 
*/
uint8_t Calculate_NodeIndex(uint8_t* bdaddr)
{
  for (uint8_t count=0; count < MAX_NODE_COUNT; count++)
  {
    /* check if node presented */
    if (memcmp(sBeacon[count].BDADDR_ID,bdaddr, 6) == 0)      
    {
      return count;
    }
    
    /* check for new entry */
    else if (sBeacon[count].BDADDR_ID[0] == 0x00 &&
        sBeacon[count].BDADDR_ID[1] == 0x00 &&
        sBeacon[count].BDADDR_ID[2] == 0x00 &&
        sBeacon[count].BDADDR_ID[3] == 0x00 &&
        sBeacon[count].BDADDR_ID[4] == 0x00 &&
        sBeacon[count].BDADDR_ID[5] == 0x00 )
    {
      return count;  
    }
  }
  return 0xFF;
}

/* Hardware Error event. 
   This event is used to notify the Host that a hardware failure has occurred in the Controller. 
   Hardware_Code Values:
   - 0x01: Radio state error
   - 0x02: Timer overrun error
   - 0x03: Internal queue overflow error
   After this event is recommended to force device reset. */

void hci_hardware_error_event(uint8_t Hardware_Code)
{
   NVIC_SystemReset();
}



/****************** Power Saving API ********************************/

/** BlueNRG-1 Sleep Management Callback **/
SleepModes App_SleepMode_Check(SleepModes sleepMode)
{
//  if(SdkEvalComIOTxFifoNotEmpty() || SdkEvalComUARTBusy())
//      return SLEEPMODE_RUNNING;
  return SLEEPMODE_NOTIMER;   
}



/**
* @brief  Update_Scan_Interval: Update Scan Interval 
* @param  aScanInterval: 
* @retval void 
*/
tBleStatus Update_Scan_Interval( uint16_t aScanInterval,uint16_t aScanWindow)
{
 return hci_le_set_scan_parameters(PASSIVE_SCAN, aScanInterval,aScanWindow,
                                   PUBLIC_ADDR,NO_WHITE_LIST_USE);
  
}

/**
* @brief  Update_Adv_Interval: Update Adv Interval in High probability detection 
* @param  aAdvInterval_Min: Minimum advertising interval
* @param  aAdvInterval_Max: Maximum advertising interval
* @retval uint8_t return type 
*/
tBleStatus Update_Adv_Interval( uint16_t aAdvInterval_Min,uint16_t aAdvInterval_Max)
{
  
   /* Set AD Type Flags at beginning on Advertising packet  */
  uint8_t adv_data[] = {
      /* Advertising data: Flags AD Type */
      0x02, 
      0x01, 
      0x06, 
      /* Advertising data: manufacturer specific data */
      26, //len
      AD_TYPE_MANUFACTURER_SPECIFIC_DATA,  /*manufacturer type*/
      0x30, 0x00, /* Company identifier code (Default is 0x0030 - STMicroelectronics: To be customized for specific identifier)*/
      0x02,       /* ID */
      0x15,       /* Length of the remaining payload */
      abs(TiltAngleX), abs(TiltAngleY), abs(TiltAngleZ) ,0xF4, 0x73, 0xF5, 0x4B, 0xC4,    /*tilt of board is included in adv packet */
      0xA1, 0x2F, 0x17, 0xD1, 0xAD, 0x07, 0xA9, 0x61,
      0x00, 0x00, /* Major number */
      0x00, 0x00, /* Minor number */
      0xC8        /* 2's complement of the Tx power (-56dB)} */     
   };
    
  /* Set the  ADV data with the Flags AD Type at beginning of the 
     advertsing packet,  followed by the beacon manufacturer specific data */
 return hci_le_set_advertising_data (sizeof(adv_data), adv_data);

}

#ifdef LOW_POWER_FEATURE
/**
* @brief  State Machines for Sleep Mode 
* @param  None
* @retval void
*/
void Sleep_State()
{
  switch( DeviceState )
  {
  case IdleMode:
    break;
    
  case NormalMode:
    hci_le_set_scan_response_data(0,NULL);  
    aci_gap_set_discoverable(ADV_NONCONN_IND, ADV_INTERVAL_MIN, ADV_INTERVAL_MAX, PUBLIC_ADDR, NO_WHITE_LIST_USE,
                             0, NULL, 0, NULL, 0, 0); 
    aci_gap_start_observation_proc(SCAN_INTERVAL,SCAN_WINDOW,NO_WHITE_LIST_USE, PUBLIC_ADDR, 0x00, 0x00);
    /*    Update_Scan_Interval(SCAN_INTERVAL,SCAN_WINDOW); */
    Update_Adv_Interval(ADV_INTERVAL_MIN,ADV_INTERVAL_MAX);
    DeviceState = IdleMode;
    break;
    
  case LowProbabilityDetection:
    break;
    
  case HighProbabilityDetection:
    BEACON_Count = 0; /* Reset count */    
    /* High probability detection mode, increase Adv and scan freq */
    PRINTF("****High Probability Detection ****\r\n");
    Update_Scan_Interval(HIGH_PROBABILITY_ADV_SCAN_INTERVAL,HIGH_PROBABILITY_ADV_SCAN_WINDOW);
    Update_Adv_Interval(HIGH_PROBABILITY_ADV_INTERVAL_MIN,HIGH_PROBABILITY_ADV_INTERVAL_MAX);
    break;
    
  case SleepMode:
    aci_gap_terminate_gap_proc(GAP_OBSERVATION_PROC);
    aci_gap_set_non_discoverable();
    DeviceState = NormalMode;
    BEACON_Count = 0; 
    BEACON_LossCount = 0;
    WhiteLedOn();   /*white led on before sleep to avoid any interfernce of other led state*/
    PRINTF("RADIO IN SLEEP MODE DUE TO TIMER \r\n"); 
    /* Enable the Sleep - SLEEPMODE_WAKETIMER */
    Appli_LowPowerProcess();        
    break;
    
  case NoMovementDetection:
    aci_gap_terminate_gap_proc(GAP_OBSERVATION_PROC);
    aci_gap_set_non_discoverable();

    DeviceState = NormalMode;  
    PRINTF("NoMovementDetection : RADIO IN SLEEP MODE\r\n"); 
    BEACON_Count = 0; 
    BEACON_LossCount = 0;
    /* Enable the Standby - SLEEPMODE_NOTIMER */
    Sleep_NoMovementDetection();
    break;
  default:
    break; 
  } 
  if (DeviceState != NormalMode)
  {
    DeviceState = IdleMode;
  }
}

/**
* @brief  Sleep and Wake up from accelerometer 
* @param  None
* @retval void
*/
void Sleep_NoMovementDetection()
{  
  uint8_t ret =0;
   HAL_VTimer_Stop(0);
   HAL_VTimer_Stop(1);
   HAL_VTimer_Stop(2);
  /* To start virtual timer */
  BTLE_StackTick();   
  //SysTick->CTRL = 0;
  /* Check UART Busy status */
 // while(SdkEvalComUARTBusy() == SET); 
#ifdef BLUENRG_TILE 
  ret =  BlueNRG_Sleep(SLEEPMODE_NOTIMER, WAKEUP_IO13, (WAKEUP_IOx_LOW << WAKEUP_IO13_SHIFT_MASK));
#else
  ret = BlueNRG_Sleep(SLEEPMODE_NOTIMER, WAKEUP_IO12,(WAKEUP_IOx_HIGH << WAKEUP_IO12_SHIFT_MASK)); 
#endif
  if (ret != SUCCESS) 
  {
    PRINTF("BlueNRG_Sleep() error 0x%02x\r\n", ret);
    while(1);
  }
  HAL_VTimer_Stop(0);
  printWakeupSource();
   
}

/**
* @brief  Output the Wake up source 
* @param  None
* @retval void
*/
void printWakeupSource()
{
  uint16_t src;
  
  PRINTF("WAKEUP Reason = ");

  src = BlueNRG_WakeupSource();
  
  if (src & WAKEUP_IO9)
    PRINTF("IO-9 ");
  
  if (src & WAKEUP_IO10)
    PRINTF("IO-10 ");

  if (src & WAKEUP_IO11)
    PRINTF("IO-11 ");

  if (src & WAKEUP_IO12)
    PRINTF("IO-12 ");

  if (src &WAKEUP_IO13)
    PRINTF("IO-13 ");

  if (src & WAKEUP_SLEEP_TIMER1)
    PRINTF("SLEEP TIMER1 ");

  if (src & WAKEUP_SLEEP_TIMER2)       
    PRINTF("SLEEP TIMER2 ");
  
  
  if (src & WAKEUP_BOR)
    PRINTF("BOR ");

  if (src & WAKEUP_POR)
    PRINTF("POR ");

  if (src & WAKEUP_SYS_RESET_REQ)
    PRINTF("SYS RESET REQ ");

  if (src & WAKEUP_RESET_WDG)
    PRINTF("WDG ");

  if (src & NO_WAKEUP_RESET)
    PRINTF("NO WAKEUP RESET ");
  PRINTF ("\r\n");
}

#endif //LOW_POWER_FEATURE
/***************************************************************************************/

/*******************************************************************************
 * Function Name  : GPIO_Configuration.
 * Description    : Configure outputs GPIO pins
 * Input          : None
 * Return         : None
 *******************************************************************************/
void GPIO_Configuration(void) 
{
  GPIO_InitType GPIO_InitStructure;
  
  /** GPIO Periph clock enable */
  SysCtrl_PeripheralClockCmd(CLOCK_PERIPH_GPIO, ENABLE);
  
  /** Init Structure */
  GPIO_StructInit(&GPIO_InitStructure);
  
  /** Configure GPIO_Pin_7 for Proximity XSHUT*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Output;
  GPIO_InitStructure.GPIO_Pull = DISABLE;
  GPIO_InitStructure.GPIO_HighPwr = ENABLE;
  GPIO_Init(&GPIO_InitStructure);
  
  GPIO_WriteBit(GPIO_Pin_7, Bit_RESET);
  
}

#ifdef  USE_FULL_ASSERT

/**
* @brief  Reports the name of the source file and the source line number
*         where the assert_param error has occurred.
* @param  file: pointer to the source file name
* @param  line: assert_param error line source number
*/
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
  ex: PRINTF("Wrong parameters value: file %s on line %d\r\n", file, line) */
  
  /* Infinite loop */
  while (1)
  {
  }
}

#endif

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
/** 
 */
