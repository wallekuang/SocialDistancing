/******************** (C) COPYRIGHT 2020 STMicroelectronics ********************
  * @file    BlueNRG1_it.c 
  * @author  SRA-SAIL
  * @version V1.0.0
  * @date    29-May-2020
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2015 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "BlueNRG1_it.h"
#include "BlueNRG1_conf.h"
#include "ble_const.h"
#include "bluenrg1_stack.h"
#include "SDK_EVAL_Com.h"
#include "clock.h"
#include "sensor.h"
#include "sleep.h"

#ifndef SENSOR_EMULATION
#include "LSM6DSO.h"
#include "LSM6DSO_hal.h"
#endif /* SENSOR_EMULATION */
    
/** @addtogroup Social_Distancing_Application
  * @{
  */

/** @addtogroup GPIO_Examples
  * @{
  */ 

/** @addtogroup GPIO_IOToggle
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
static volatile tClockTime TICK_Count;
volatile uint8_t AXEL_EventDetected = 0; 
extern uint8_t ReadAccValue;

#define COUNTER_500MS             500

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M0 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
* @brief  NMI_Handler
* @brief  This function handles NMI exception.
* @param  None 
* @retval None
*/
void NMI_Handler(void)
{
  
}

/**
* @brief  HardFault_Handler
* @brief  This function handles Hard Fault exception.
* @param  None 
* @retval None
*/
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {}
}

/**
* @brief  SVC_Handler
* @brief  This function handles SVCall exception.
* @param  None 
* @retval None
*/
void SVC_Handler(void)
{
  
}

/**
* @brief  SysTick_Handler
* @brief  This function handles SysTick Handler
* @param  None 
* @retval None
*/
void SysTick_Handler(void)
{
  SysCount_Handler(); 
  TICK_Count = Clock_Time();
  if((TICK_Count % COUNTER_500MS) == 0) 
  {
    ReadAccValue = 1;
  }  
}

/**
* @brief  GPIO_Handler
* @brief  This function handles Gpio Interrupt
* @param  None 
* @retval None
*/
void GPIO_Handler(void)
{
  if (GPIO_GetITPendingBit(SDK_EVAL_IRQ_SENSOR_PIN) == SET 
      || ((wakeupFromSleepFlag) && (BlueNRG_WakeupSource() & WAKEUP_IO13)))
  {  
    GPIO_ClearITPendingBit(SDK_EVAL_IRQ_SENSOR_PIN);
    GPIO_EXTICmd(SDK_EVAL_IRQ_SENSOR_PIN, DISABLE);
    AXEL_EventDetected = 1;
  }

}
/******************************************************************************/
/*                 BlueNRG-1 Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (system_bluenrg1.c).                                               */
/******************************************************************************/
/**
* @brief  UART_Handler
* @brief  This function handles UART interrupt request.
* @param  None 
* @retval None
*/
void UART_Handler(void)
{
  
//  if (UART_GetITStatus(UART_IT_RX) != RESET) 
//  {
//    /* Clear the interrupt */
//    UART_ClearITPendingBit(UART_IT_RX);
//  }  
}

/**
* @brief  Blue_Handler
* @brief  This function call Radio ISR routine.
* @param  None 
* @retval None
*/
void Blue_Handler(void)
{
   // Call RAL_Isr
   RAL_Isr();
}

/**
  * @}
  */ 

/**
  * @}
  */ 

/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2020 STMicroelectronics *****END OF FILE****/
